package c_s_p.catalog;

	import org.springframework.context.annotation.Bean;
	import org.springframework.context.annotation.ComponentScan;
	import org.springframework.context.annotation.Configuration;

	@Configuration
	@ComponentScan(basePackages = "BeanAnnotation")
	public class CatalogConfigure {
		
		@Bean
		public CatalogData catalogBean(){
			return new CatalogData();
		}
		}
