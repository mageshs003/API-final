package c_s_p.orders_for_enterprise;

	import org.springframework.context.annotation.Bean;
	import org.springframework.context.annotation.ComponentScan;
	import org.springframework.context.annotation.Configuration;

	@Configuration
	@ComponentScan(basePackages = "BeanAnnotation")
	public class OrderEnterpriseConfigure {
		
		@Bean
		public OrderEnterpriseData orderEnterpriseBean(){
			return new OrderEnterpriseData();
		}
		}
